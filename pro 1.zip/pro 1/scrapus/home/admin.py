from django.contrib import admin
from home.models import Contact,Sell

# Register your models here.
admin.site.register(Contact),
admin.site.register(Sell)


