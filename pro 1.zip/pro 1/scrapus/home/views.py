from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from datetime import datetime
from home.models import Contact,Sell



# Create your views here.

def HomePage(request):
    return render(request,'home.html')

def HomePage2(request):
    return render(request,'home2.html')

def RatePage(request):
    return render(request,'rate.html')   

def Paper(request):
    return render(request,'paper.html')

def Plastic(request):
    return render(request,'plastic.html')   

def Clothes(request):
    return render(request,'clothes.html') 

def Metal(request):
    return render(request,'metal.html')

def Ewaste(request):
    return render(request,'ewaste.html')    

def Others(request):
    return render(request,'others.html')      

def sell(request):
    if request.method=='POST':
        name = request.POST.get('name')  
        mobile = request.POST.get('mobile')  
        email = request.POST.get('email')  
        address = request.POST.get('address')
        sell=Sell(name=name,mobile=mobile,email=email,address=address,date=datetime.today())
        sell.save()
        return redirect ('rate') 
    return render(request,'sell.html') 
            

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')  
        mobile = request.POST.get('mobile')  
        email = request.POST.get('email')  
        message = request.POST.get('message')  
        contact = Contact(name=name, mobile=mobile, email=email, message=message, date=datetime.today())
        contact.save()
        return redirect('home')
        messages.success(request, "Your response is received.")

    return render(request, 'contacts.html')

def SignupPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')
        if pass1!=pass2:
            return HttpResponse("password and password2 are not same!try again.")
        else:
            my_user=User.objects.create_user(username,email,pass1 )
            my_user.save()
            return redirect('login')
        
    return render(request,'signup.html')

def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect ('home2')
        else:
            return Httpresponse("username or password is incorrect")   

    return render(request,'login.html')

def about(request):
    return render(request,'about.html')
    
def logOut(request):
    logout(request)
    return redirect("/home")   