"""
URL configuration for scrapus project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from home import views

admin.site.site_header= "SCRAP WALA"
admin.site.site_title= "SCRAP WALA Admin portal"
admin.site.index_title= "Welcome to SCRAP WALA"

urlpatterns = [
    path('admin', admin.site.urls),
    path('signup',views.SignupPage,name='signup'),
    path('login',views.LoginPage,name='login'),
    path('logout',views.logOut,name='logout'),
    path('',views.HomePage,name='home'),
    path('home',views.HomePage,name='home'),
    path('home2',views.HomePage2,name='home2'),
    path('rate',views.RatePage,name='rate'),
    path('paper',views.Paper,name='paper'),
    path('plastic',views.Plastic,name='plastic'),
    path('clothes',views.Clothes,name='clothes'),
    path('metal',views.Metal,name='metal'),
    path('ewaste',views.Ewaste,name='ewaste'),
    path('others',views.Others,name='others'),
    path('contact',views.contact,name='contact'),
    path('sell',views.sell,name='sell'),
    path('about',views.about,name='about'),
]
